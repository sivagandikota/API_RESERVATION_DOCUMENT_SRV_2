@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/SD/Global2")
package com.sap.xi.sd.global2;
