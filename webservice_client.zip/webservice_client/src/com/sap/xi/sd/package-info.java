@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/SD")
package com.sap.xi.sd;
