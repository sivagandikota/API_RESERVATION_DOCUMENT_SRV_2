@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/SD-SLS")
package com.sap.xi.sd_sls;
