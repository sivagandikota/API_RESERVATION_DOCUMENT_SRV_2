@javax.xml.bind.annotation.XmlSchema(namespace = "http://sap.com/xi/SAPGlobal20/Global")
package com.sap.xi.sapglobal20.global;
