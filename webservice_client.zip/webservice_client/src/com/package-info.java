@javax.xml.bind.annotation.XmlSchema(namespace = "http://com/")
package com;
